# Meus NPC's Ragnarok Online
Script dos meus NPC's
* Do meu servidor (emulador) estou disponibilizando alguns npc's que desenvolvi e outros que editei.

## Jogo: Ragnarok Online
* RPG MMO 2D Online

# NPC:
* Imagens exemplos de um NPC:

![GM](https://i.ibb.co/TbMFyq6/1-removebg-preview.png)
![VALKFAKE](https://i.ibb.co/k5pqCxL/walk-removebg-preview.png)

# NPC Funcionando dentro do jogo
* OBS: Imagem recortada para melhor visualização. 
* Meu NPC "Suporte para GM iniciante" in-game:

![Imagem recortada: NPC funcionando dentro do jogo SUPORTE STAFF](https://i.ibb.co/HHwxhFf/screen-Nordic-BR002-Copia.jpg)
